// all custom JS here //
$(document).ready(function () {
    $(".mobileMenu").click(function () {
        $(".mobileMenuBox").show().css("left", "0");
    });

    $(".mobile_head .close").click(function () {
        $(".mobileMenuBox").hide().css("left", "-200%");
    });
    //Traveler home and Results
    $(".traveller").click(function () {
        $(".travllerBox").slideDown();
        /* $(".module-bg").show();*/
    });
    $(".done_Btn").click(function () {
        $(".travllerBox").slideUp();
        /* $(".module-bg").hide();*/
    });

    $(document).on('click touch', function (event) {
        if (!$(event.target).parents().addBack().is('.traveller, .currencyClick')) {
            $('.travllerBox').slideUp();
            $('.module-bg').hide();
            $('.currencyBox ul').hide();
        }
    });
    $('.travllerBox, .currencyClick, .currencyClick').on('click touch', function (event) {
        event.stopPropagation();
    });


    $(".currencyClick").click(function () {
        $(this).next().slideToggle();
    });



    //Slick destination slider for home page

    $('.destination_slider').slick({
        dots: false,
        infinite: false,
        speed: 300,
        slidesToShow: 6,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    arrows: false,
                    dots: true

                }
            },
            {
                breakpoint: 767,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 1

                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1

                }
            }

        ]
    });

    //Slick service slider  for home page
    $('.service_slider').slick({
        dots: false,
        infinite: false,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 3,
        responsive: [

            {
                breakpoint: 10000,
                settings: "unslick"
            },


            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true,
                    settings: "slick"
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    dots: true,
                }
            },
            {
                breakpoint: 630,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    dots: true,
                }
            }

        ]
    });

});//Document close

$(document).ready(function () {
    //Slick Most popular  for airline page
    $('.popular_slider').slick({
        dots: false,
        infinite: false,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [

            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true,
                    settings: "slick"
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    dots: true,
                }
            },
            {
                breakpoint: 630,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    dots: true,
                }
            }
        ]
    });
    //End most popular slider
});

//
// Cookies
function createCookie(name, value, days) {

    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    }
    else var expires = "";

    document.cookie = name + "=" + value + expires + "; path=/";
}
function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function eraseCookie(name) {
    createCookie(name, "", -1);
}

(function ($) {
    $.fn.serializeFormJSON = function () {
        var o = {};
        var a = this.serializeArray();
        $.each(a, function () {
            if (o[this.name]) {
                if (!o[this.name].push) {
                    o[this.name] = [o[this.name]];
                }
                o[this.name].push(this.value || '');
            } else {
                o[this.name] = this.value || '';
            }
        });
        return o;
    };
})(jQuery);
!function (n) { "use strict"; n.fn.idle = function (e) { var t, i, o = { idle: 6e4, events: "mousemove keydown mousedown touchstart", onIdle: function () { }, onActive: function () { }, onHide: function () { }, onShow: function () { }, keepTracking: !0, startAtIdle: !1, recurIdleCall: !1 }, c = e.startAtIdle || !1, d = !e.startAtIdle || !0, l = n.extend({}, o, e), u = null; return n(this).on("idle:stop", {}, function () { n(this).off(l.events), l.keepTracking = !1, t(u, l) }), t = function (n, e) { return c && (e.onActive.call(), c = !1), clearTimeout(n), e.keepTracking ? i(e) : void 0 }, i = function (n) { var e, t = n.recurIdleCall ? setInterval : setTimeout; return e = t(function () { c = !0, n.onIdle.call() }, n.idle) }, this.each(function () { u = i(l), n(this).on(l.events, function () { u = t(u, l) }), (l.onShow || l.onHide) && n(document).on("visibilitychange webkitvisibilitychange mozvisibilitychange msvisibilitychange", function () { document.hidden || document.webkitHidden || document.mozHidden || document.msHidden ? d && (d = !1, l.onHide.call()) : d || (d = !0, l.onShow.call()) }) }) } }(jQuery);

// all custom JS here //
$(document).ready(function () {

    $(document).on('click touch', function (event) {
        if (!$(event.target).parents().addBack().is('.traveller, .currencyClick')) {
            $('.travllerBox').slideUp();
            $('.currencyBox ul').hide();
        }
    });

    //start fare breakup
    $(".fare__detail").click(function () {
        $(".fare_breakup_detail").hide();
        $(this).next().slideDown();
    });
    $(".close_price_breakup").click(function () {
        $(".fare_breakup_detail").slideUp();
    });

    $(document).on('click touch', function (event) {
        if (!$(event.target).parents().addBack().is('.fare__detail')) {
            $('.fare_breakup_detail').slideUp();
        }
    });
    $('.fare_breakup_detail').on('click touch', function (event) {
        event.stopPropagation();
    });
    // End fare breakup

    //Results page
    $(".mobile__filter ul li, .filter_link").click(function () {
        $(".leftCntr").addClass("open-filter");
        $(".results_body").addClass("open-model");

    });

    $(".close_filter").click(function () {
        $(".leftCntr").removeClass("open-filter");
        $(".results_body").removeClass("open-model");

    });


    //
    $(".flight_detail_btn").click(function () {
        $(".flightDetailWrapper").css("width", "100%")
        $("body").addClass("open-model")
    });

    $(".close_detail").click(function () {
        $(".flightDetailWrapper").css("width", "0%")
        $("body").removeClass("open-model")
    });

});
//Rang slider
$(function () {
    $(".slider-range").slider({
        range: true,
        min: 0,
        max: 500,
        values: [82, 580],
        slide: function (event, ui) {
            $("#amount").val("$" + ui.values[0] + " - $" + ui.values[1]);
        }
    });

});
//Rang slider
//Tab function
function clickTabShow(id, tab) {
    $("#departTabcontent").hide();
    $("#returnTabcontent").hide();
    $("#" + id).show();
    $(".tabclick").removeClass("active");
    $("#" + tab).addClass('active');
}

function currencyChange(currency) {
    var priceRange = window.location.href.indexOf("availability") > -1 ? true : false;
    $.ajax({
        url: DOMAIN_URL + "flights/getcurrency/" + currency,
        type: 'GET',
        contentType: "application/json; charset=utf-8", success: function (response) {
            if (response.IsSuccess) {
                $(".curClass").html(response.data.CurrencyType);
                $('#currencyul').hide();
                u = response.data.CurrencyPrice;
                r = response.data.CurrencySymbol;
                ct = response.data.CurrencyType;
                $(".chgCurrency").each(function (n, t) {
                    if ($(this).attr("default-price")) {
                        var i = $(this).attr("default-price");
                        $(this).html(r)
                    }
                });
                $(".chgcomplete").each(function (n, t) {
                    if ($(this).attr("default-price")) {
                        var i = $(this).attr("default-price");
                        var totalSub = ((i * u).toFixed(2).toString());
                        $(this).html(r + totalSub)
                    }
                });

                $(".chgCurrencyTwo").each(function (n, t) {
                    if ($(this).attr("default-price")) {
                        var i = $(this).attr("default-price");
                        var totalSub = ((i * u).toString().split(".")[0]);
                        $(this).html(totalSub);
                    }
                });
                $(".chgWithCurrency").each(function (n, t) {
                    if ($(this).attr("default-price")) {
                        var i = $(this).attr("default-price");
                        var totalSub = ((i * u).toString().split(".")[0]);
                        $(this).html(r + totalSub);
                    }
                });
                $(".chgCurrencySub").each(function (n, t) {
                    if ($(this).attr("default-price")) {
                        var i = $(this).attr("default-price");
                        var totalSub = ((i * u).toFixed(2).toString().split(".")[1]);
                        $(this).html("." + totalSub);
                    }
                });
                $(".chgdiscount").each(function (n, t) {
                    if ($(this).attr("default-price")) {
                        var i = $(this).attr("default-price");
                        var totalSub = ((i * u).toFixed(2).toString());
                        $(this).html('-' + r + totalSub)
                    }
                });
                $(".chgtype").each(function (n, t) {
                    $(this).html(ct)
                });
               
                if (priceRange) {
                    $("#priceRange").attr("data-default-currencyPrice", u);
                    $("#priceRange").attr("data-default-currencySymbol", r);
                    $(".chgslidercomplete").each(function (n, t) {
                        if ($(this).attr("current-price")) {
                            var i = $(this).attr("current-price");
                            var totalSub = ((i * u).toFixed(2).toString());
                            $(this).html(r + totalSub)
                        }
                        if (priceRange && $("#priceTab").attr("pricetabmin") != undefined) {
                            var minPrice = ((u * $("#priceTab").attr("pricetabmin")).toFixed(2).toString());
                            var maxPrice = ((u * $("#priceTab").attr("pricetabmax")).toFixed(2).toString());
                            $("#priceTabChange").html(r + minPrice + "-" + r + maxPrice);
                        }
                    });
                }
            }
        },
        start: function () { }, complete: function (data) { }
    });
}

$(document).ready(function () {
    $(".NewSearch").click(function () {
        window.location = "/";
    });
    $(".RefreshResults").click(function () {
        location.reload();
    });
    $('.relaunchSearch').click(function () {
        $('#flights').submit();
    })
});

function getDeals() {
    var url = DOMAIN_URL + "flights/getdeals";
    $.ajax({
        type: "POST",
        url: url,
        success: function (response) {
            if (response.IsSuccess) {
                $("#flightDeal").html(response.HtmlResponse);
                airlineDeals();
                dealSliderinit();
            }
        },
        error: function (error) {
            console.log(error);
        }
    });
}

function loadSliderJs() {
    $('.airline-deals').slick({
        dots: false,
        infinite: false,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    arrows: false,
                    dots: true

                }
            },
            {
                breakpoint: 767,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 1

                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1

                }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
        ]
    });
}

function airlineDeals() {

    $('.flight-deals').slick({
        dots: false,
        infinite: false,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    arrows: false,
                    dots: true

                }
            },
            {
                breakpoint: 767,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 1

                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1

                }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
        ]
    });



}

function getCurrency() {
    var url = DOMAIN_URL + "flights/getcurrency";
    $.ajax({
        type: "POST",
        url: url,
        success: function (response) {
            if (response.IsSuccess) {
                currencyChange(response.HtmlResponse)
            }
        },
        error: function (error) {
            console.log(error);
        }
    });
}

function getNearByAirport() {
    var cookieVal = jQuery.parseJSON(readCookie('searchPerms'));
    if (cookieVal == null && $('#OriginSearch').val() == "" && $('#DestinationSearch').val() == "") {

        var url = DOMAIN_URL + "flights/naer-by-airport";
        $.ajax({
            type: "POST",
            url: url,
            success: function (response) {
                if (response.IsSuccess) {
                    if (response.HtmlResponse.IsMobile) {
                        $('#OriginSearch').val(response.HtmlResponse.OriginSearch);
                        $('#Origin').val(response.HtmlResponse.Origin);
                        $('#inputOrigin').addClass('valid');
                        $('#inputOrigin').val(response.HtmlResponse.OriginSearch);
                    } else {                        
                        $('.origsuggestion').removeClass('d-none');
                        $('#OriginSearch').val(response.HtmlResponse.Origin);
                        $('#OriginSearchDes').html(response.HtmlResponse.OriginSearchDes);                        
                        $('#OriginSearchDescription').val(response.HtmlResponse.OriginSearchDes);
                    }

                }
            },
            error: function (error) {
                console.log(error);
            }
        });
    }
}

$(document).ready(function () {
    getNearByAirport();
    getCurrency();
    //getReviews();
    getDeals();

});


function startTimeCount() {
    var projectedTime = new Date().getTime() + 15 * 1000 * 60;
    var timeInterval = setInterval(() => {
        var currentTime = new Date().getTime()
        var CountDownTime = projectedTime - currentTime;
        var Minute = Math.floor((CountDownTime % (1000 * 60 * 60)) / (1000 * 60))
        var second = Math.floor((CountDownTime % (1000 * 60)) / 1000);
        if ($("#countdown").length) {
            document.getElementById("countdown").innerHTML = Minute + "m " + second + "s";
        }
        if (CountDownTime <= 0) {
            clearInterval(timeInterval);
        }
    }, 1000)
}

function readMoetext() {
    var maxLength = 100;
    $(".show-read-more").each(function () {
        var myStr = $(this).text();
        if ($.trim(myStr).length > maxLength) {
            var newStr = myStr.substring(0, maxLength);
            var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
            $(this).empty().html(newStr);
            $(this).append(' <a href="javascript:void(0);" style="text-decoration:none" class="read-more">read more...</a>');
            $(this).append('<span class="more-text">' + removedStr + '</span>');
        }
    });
    $(".read-more").click(function () {
        $(this).siblings(".more-text").contents().unwrap();
        $(this).remove();
    });
}


/* Contact Us */


function validate() {
    var name = document.getElementById("name").value;
    var phone = document.getElementById("phone").value;
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;
    $("#error_message").show();
    var error_message = document.getElementById("error_message");

    error_message.style.padding = "5px";

    var text;
    if (name.length < 5) {
        text = "Please Enter valid Name";
        error_message.innerHTML = text;
        setTimeout(function () { $('#error_message').hide(); }, 5000);
        return false;
    }
    if (email.indexOf('@') == -1 || email.length < 6) {
        text = "Please Enter valid Email";
        error_message.innerHTML = text;
        setTimeout(function () { $('#error_message').hide(); }, 5000);
        return false;
    }
    //if (isNaN(phone) || phone.length != 10) {
    //    text = "Please Enter valid Phone Number";
    //    error_message.innerHTML = text;
    //    setTimeout(function () { $('#error_message').hide(); }, 5000);
    //    return false;
    //}

    if (message.length <= 40) {
        text = "Please Enter More Than 40 Characters";
        error_message.innerHTML = text;
        setTimeout(function () { $('#error_message').hide(); }, 5000);
        return false;
    }
    if (!document.getElementById("contact-us-CheckBox").checked) {
        text = "Please checked the checkbox";
        error_message.innerHTML = text;
        setTimeout(function () { $('#error_message').hide(); }, 5000);
        return false;
    }
    $('#error_message').hide();
    saveContactUsDetails();
}

function saveContactUsDetails() {
    var contactUs = {};
    contactUs.Name = $("#name").val();
    contactUs.Email = $("#email").val();
    contactUs.Phone = $("#phone").val();
    contactUs.Description = $("#message").val();
    try {
        $.ajax({
            type: "POST",
            url: DOMAIN_URL + "/home/savecontactus",
            data: '{model: ' + JSON.stringify(contactUs) + '}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (result) {
                if (result.isSuccess == true) {
                    $('.clearAll').val('');
                    $("#contact-us-CheckBox").prop("checked", false);
                    $('#susses').show(500);
                    setTimeout(function () { $('#susses').hide(); }, 5000);
                    
                }
            },
            error: function (data) {
                Toast.fire({
                    icon: 'error',
                    title: 'ContactUs status failed!'
                })
            }
        });
    }
    catch (ex) {
        
        console.log(ex.stack);
    }
}

//---------------------- Affordable flights JS Starts Here --------------------------------

function isEmailItin(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}

var uniPhone = null;
function initPhone() {
    var input = document.querySelector("#phone");
    uniPhone = window.intlTelInput(input, {
        autoPlaceholder: "off",
        initialCountry: "US",
        separateDialCode: true,
        utilsScript: "/Scripts/utils.js",
    });
}

function saveAffordableFlight() {
    settimedivHide('.errortext');

    if (Origin === '' || (Origin.length) < 3) {
        $('#OriginSearch').focus();
        $(".inputOrigin").addClass('error');
        return false;
    }
    else if (Destination === '' || (Destination.length) < 3) {
        $('#DestinationSearch').focus();
        $(".inputDestination").addClass('error');
        $("#Return_error").html('Please select a destination');
        return false;
    }
    else if (Destination === Origin) {
        $('#DestinationSearch').focus();
        $(".inputDestination").addClass('error');
        $("#Return_error").html('Please enter a different Origin and Destination/City airport!');
        return false;
    }

    if ($('#OriginSearch').val() == '' || $('#OriginSearch').val().length < 2 || $('#OriginSearch').val().length > 25) {
        $("#Depart_error").html('Please select an destination');
        $("#Depart_error").show();
        $('#OriginSearch').focus();
        return;
    }

    if ($('#DestinationSearch').val() == '' || $('#DestinationSearch').val().length < 2 || $('#DestinationSearch').val().length > 25) {
        $("#Return_error").html('Please select a destination');
        $("#Return_error").show();
        $('#DestinationSearch').focus();
        return;
    }



    if ($('#name').val() == '' || $('#name').val().length < 2 || $('#name').val().length > 25) {
        $("#Name_error").html('Please enter your full name!');
        $("#Name_error").show();
        $('#name').focus();        
        return;
    }

    if (!isEmailItin($('#email').val()) || $('#email').val().length > 200) {
        $("#Email_error").html('Please enter valid email id!');
        $("#Email_error").show();
        $('#email').focus();    
        return;
    }

    if (!uniPhone.isValidNumber()) {
        $("#Phone_error").html('Please enter valid phone number!');
        $("#Phone_error").show();
        $('#phone').focus();    
        return;
    }

    $.ajax(
        {
            type: "POST",
            url: DOMAIN_URL + "flights/requestacall",
            data: {
                phone: uniPhone.getNumber(),
                itinGuid: $("#phoneitinGuid").val(),
                ContractId: $("#phonecontractId").val(),
                Email: $('#email').val(),
                Name: $('#name').val()
            },
            success: function (result) {
                $("#mainBody").hide();
                $('#sentSuccess').show();
            },
            error: function (request, error) {
                $("#mainBody").hide();
                $('#sentSuccess').show();
            },

        });

    function settimedivHide(data) {
        setTimeout(function () {
            $(data).fadeOut(1500);
            $(data).removeClass('error');
            $(data).removeClass('error');
        }, 3000);

    }

}

function newRequest() {
    $('#name').val(''); 
    $('#email').val(''); 
    if (uniPhone != null) {
        $('#phone').val('');
        uniPhone.destroy();
    } 
    $('#sentSuccess').hide();
    $('#mainBody').show();
    initPhone();
}
//---------------------- Affordable flights JS Ends Here --------------------------------

// -------- offer-slider -----

$(document).ready(function () {

    dealSliderinit();

});


$(document).ready(function () {

    $('.reviews-slider').slick({
        dots: false,
        infinite: false,
        arrows: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    arrows: false,
                    dots: true

                }
            },
            {
                breakpoint: 767,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 1

                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1

                }
            }
           
        ]
    });
    

});

$(document).ready(function () {

    $('.reviews-sliders').slick({
        dots: true,
        infinite: false,
        arrows: false,
        speed: 300,
        slidesToShow: 2,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    arrows: false,
                    dots: true

                }
            },
            {
                breakpoint: 767,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 1

                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1

                }
            }

        ]
    });

});

$(document).ready(function () {

    $('.destination-slider').slick({
        dots: false,
        infinite: false,
        arrows: true,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    arrows: false,
                    dots: true

                }
            },
            {
                breakpoint: 767,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 1

                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1

                }
            }

        ]
    });


});

$(document).ready(function () {

    $('.business-slider').slick({
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        dots: true,
        arrows: false,
        
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    arrows: false,
                    dots: true

                }
            },
            {
                breakpoint: 767,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1

                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1

                }
            }

        ]
    });


});

$(document).ready(function () {
    $("#btnSubscriber").click(function () {
        if (!isEmailItin($('#emailsub').val())) {
            $('#emailsub').focus();
            $('#emailsub').css({ 'border': "solid 1px red" });
            $('.error').css({ 'display': "block"});
            return false;
        }
        else {
            $.ajax(
                {
                    type: "POST",
                    url: DOMAIN_URL + "flights/addsubscription",
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    data: JSON.stringify({ email: $("#emailsub").val() }),
                    success: function (result) {
                    },
                });
         
            $('.subs-sec').hide();
            $('.thksub').css({ 'display': "block" });
        }
    });
    $("#emailsub").keyup(function () {
        $(this).css({ 'border': "solid 1px #0156a6"});
        $('.error').css({ 'display': "none" });
    });
    $('.media-slider').slick({
        dots: false,
        arrows: false,
        autoplay: true,
        autoplaySpeed: 2000,
        slidesToShow: 6,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 6,
                    slidesToScroll: 1,
                    infinite: true,
                    arrows: false,
                    dots: false,

                }
            },
            {
                breakpoint: 767,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 1

                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1

                }
            }

        ]
    });
       });

function dealSliderinit() {
    $('.offer-slider').slick({
        dots: false,
        infinite: false,
        arrows: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    arrows: false,
                    dots: true
                }
            },
            {
                breakpoint: 767,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    arrows: false,
                    centerMode: true,
                    centerPadding: '0px',
                    infinite: true,
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
        ]
    });
    $('button[data-bs-toggle="tab"]').on('shown.bs.tab', function(e) {
        $('.offer-slider').slick('setPosition');
    });
}



function saveRequestCall() {
    settimedivHide('.errortext');

    if (Origin === '' || (Origin.length) < 3) {
        $('#OriginSearch').focus();
        $(".inputOrigin").addClass('error');
        return false;
    }
    else if (Destination === '' || (Destination.length) < 3) {
        $('#DestinationSearch').focus();
        $(".inputDestination").addClass('error');
        $("#Return_error").html('Please select an destination');
        return false;
    }
    else if (Destination === Origin) {
        $('#DestinationSearch').focus();
        $(".inputDestination").addClass('error');
        $("#Return_error").html('Please enter a different Origin and Destination/City airport!');
        return false;
    }

    if ($('#OriginSearch').val() == '' || $('#OriginSearch').val().length < 2 || $('#OriginSearch').val().length > 25) {
        $("#Depart_error").html('Please select an destination');
        $("#Depart_error").show();
        $('#OriginSearch').focus();
        return;
    }

    if ($('#DestinationSearch').val() == '' || $('#DestinationSearch').val().length < 2 || $('#DestinationSearch').val().length > 25) {
        $("#Return_error").html('Please select an destination');
        $("#Return_error").show();
        $('#DestinationSearch').focus();
        return;
    }



    if ($('#name').val() == '' || $('#name').val().length < 2 || $('#name').val().length > 25) {
        $("#Name_error").html('Please enter your full name!');
        $("#Name_error").show();
        $('#name').focus();
        return;
    }

    if (!isEmailItin($('#email').val()) || $('#email').val().length > 200) {
        $("#Email_error").html('Please enter valid email id!');
        $("#Email_error").show();
        $('#email').focus();
        return;
    }

    if (!uniPhone.isValidNumber()) {
        $("#Phone_error").html('Please enter valid phone number!');
        $("#Phone_error").show();
        $('#phone').focus();
        return;
    }
    var request = {};

    request.Phone = uniPhone.getNumber();
    request.Name = $('#name').val();
    request.Email = $('#email').val();
    request.Origin = $('#Origin').val();
    request.Destination = $('#Destination').val();
    request.TripType = $('#TripType').val();
    request.Departure = $('#Departure').val();
    request.Return = $('#Return').val();
    request.Adult = $('#Adult').val();
    request.Child = $('#Child').val();
    request.Infant = $('#InfantOnLap').val();
    request.Cabin = $('input[name=Cabin]:checked').val();
    request.EnquiryType = $('#EnquiryType').val();

    $.ajax(
        {
            type: "POST",
            url: DOMAIN_URL + "flights/request-for-call",
            data: '{model: ' + JSON.stringify(request) + '}',
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (result) {
                $("#mainBody").hide();
                $('#sentSuccess').show();
            },
            error: function (request, error) {
                $("#mainBody").hide();
                $('#sentSuccess').show();
            },

        });

    function settimedivHide(data) {
        setTimeout(function () {
            $(data).fadeOut(1500);
            $(data).removeClass('error');
            $(data).removeClass('error');
        }, 3000);

    }

}
